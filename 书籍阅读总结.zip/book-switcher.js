/**
 * 书籍切换器：左上角下拉菜单，用于在不同书籍间切换
 * @module book-switcher
 */

(function () {
  const switcher = document.querySelector('[data-book-switcher]');
  if (!switcher) return;

  const btn = switcher.querySelector('.book-switcher-btn');
  const list = switcher.querySelector('.book-switcher-list');
  const currentLabel = switcher.querySelector('.book-switcher-current');

  if (!btn || !list) return;

  /**
   * 根据当前页面更新显示的当前书籍名称
   */
  function syncCurrentBook() {
    const path = window.location.pathname.split('/').pop() || '';
    const is100years =
      path.startsWith('index-100years') ||
      path === 'family.html' ||
      path === 'magic-realism.html' ||
      path === 'cycles.html' ||
      path === 'solitude.html' ||
      path === 'controversy-100years.html';
    const isSapiens =
      path === 'index.html' ||
      path === 'revolutions.html' ||
      path === 'orders.html' ||
      path === 'future.html' ||
      path === 'controversy.html';
    let label = '选择书籍';
    if (is100years) label = '百年孤独';
    else if (isSapiens) label = '人类简史';
    if (currentLabel) currentLabel.textContent = label;
    const options = list.querySelectorAll('[role="option"]');
    options.forEach((opt) => {
      const selected = (is100years && opt.dataset.book === '100years') ||
        (!is100years && opt.dataset.book === 'sapiens');
      opt.setAttribute('aria-selected', selected ? 'true' : 'false');
    });
  }

  /**
   * 切换下拉列表显示状态
   */
  function toggle() {
    const isClosed = list.hasAttribute('hidden');
    if (isClosed) {
      list.removeAttribute('hidden');
      btn.setAttribute('aria-expanded', 'true');
      switcher.setAttribute('data-open', '');
    } else {
      close();
    }
  }

  /**
   * 关闭下拉列表
   */
  function close() {
    list.setAttribute('hidden', '');
    btn.setAttribute('aria-expanded', 'false');
    switcher.removeAttribute('data-open');
  }

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggle();
  });

  list.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      close();
    });
  });

  document.addEventListener('click', () => {
    if (!list.hidden) close();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !list.hidden) {
      close();
    }
  });

  /** 初始化时若列表无 hidden 则关闭 */
  if (!list.hasAttribute('hidden')) {
    list.setAttribute('hidden', '');
  }
  syncCurrentBook();
})();
